window.APP_CONFIG = {
    supabaseUrl: 'https://cehzzcvnkiuvkabglrzp.supabase.co',
    supabaseAnonKey: 'sb_publishable_-4TvQX5Ybgs6oX7HawE-LA_Uyk1FzJw'
};